const mongoose = require('mongoose')

const dbUrl = 'mongodb://localhost:27017/productDB'
mongoose.connect(dbUrl,{
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).catch(err => console.log(err))

//ออกแบบ schema
let productSchema = mongoose.Schema({
    type_account: String,
    name: String,
    price: Number,
    description: Date,
    create_save: Date,
    update_save: Date
})

let Product = mongoose.model('product', productSchema)

module.exports = Product

module.exports.saveProduct=function(model,data){
    model.save(data)
}