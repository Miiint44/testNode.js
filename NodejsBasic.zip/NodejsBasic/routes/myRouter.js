const express = require('express')
const router = express.Router()
const Product = require("../models/product")
const multer = require("multer")

const storage = multer.diskStorage({
    destination:function(req,file,cb){
        cb(null, './public/images/products')
    },
    filename:function(req,file,cb){
        cb(null,Date.now()+".jpg")
    }
})
const upload = multer({
    storage:storage
})

//ไปยังหน้าหลัก
router.get('/', (req, res) => {
    Product.find().exec((err,doc)=>{
        res.render('index',{products:doc})
    })
})

//ไปยังหน้าเพิ่มสินค้า
router.get('/add-product', (req, res) => {
    if(req.session.login){
        res.render('form')
    }else{
        res.render('admin')
    }
})

//ส่งข้อมูลไปยังหน้าจัดการสินค้า
router.get('/manage', (req, res) => {
    if(req.session.login){
        Product.find().exec((err, doc)=>{
            res.render('manage',{products:doc})
        })
    }else{
        res.render('admin')
    }
})

//ลบสินค้าโดยใช้ id ของสินค้า
router.get('/delete/:id', (req, res) => {
    Product.findByIdAndDelete(req.params.id,{useFindAndModify:false}).exec(err=>{
        if(err) console.log(err)
        res.redirect("/manage")
    })
})

//logout จากระบบ
router.get('/logout',(req,res)=>{
    req.session.destroy((err)=>{
        res.redirect('/manage')
    })
})

// แสดงรายละเอียดของสินค้าจากการอ่าน id ของสินค้า
router.get("/:id",(req, res)=>{
    const product_id = req.params.id
    Product.findOne({_id:product_id}).exec((err, doc)=>{
        res.render("product", {product:doc})
    })
})


//รับข้อมูล
router.post('/insert', upload.single("image"),(req, res) => {
    let data = new Product({
        type_account: req.body.type_account,
        name: req.body.name,
        price: req.body.price,
        description: req.body.description,
        create_save: req.body.create_save,
        update_save: req.body.update_save
    })
    Product.saveProduct(data,(err)=>{
        if(err) console.log(err)
        res.redirect("/")
    })
})

// แก้ไขข้อมูลสินค้า 
router.post('/edit', (req, res) => {
   const edit_id = req.body.edit_id
   Product.findOne({_id:edit_id}).exec((err, doc)=>{
    //นำข้อมูลเดิมที่ต้องการแก้ไข ไปแสดงในแบบฟอร์ม
    res.render("edit", {product:doc})
   })
})

//อัพเดตรายการสินค้า
router.post('/update', (req, res) => {
    //ข้อมูลใหม่ที่ถูกส่งมาจากฟอร์มการแก้ไข
    const update_id = req.body.update_id
    let data = {
        type_account: req.body.type_account,
        name: req.body.name,
        price: req.body.price,
        update_save: req.body.update_save
    }
    //อัพเดตข้อมูล
    Product.findByIdAndUpdate(update_id,data,{useFindAndModify: false}).exec(err=>{
        res.redirect("/manage")
    })
})

//ยืนยันสถานะของการ Login เข้าสู่ระบบ
router.post("/login",(req,res)=>{
    const username = req.body.username
    const password = req.body.password
    const timeExpire = 3000000

    if(username == "admin" && password == "123"){
        // res.cookie('username', username, {maxAge:timeExpire})
        // res.cookie('password', password, {maxAge:timeExpire})
        // res.cookie('login', true, {maxAge:timeExpire})
        req.session.username = username
        req.session.password = password
        req.session.login = true
        req.session.cookie.maxAge = timeExpire
        res.redirect('/manage')
    }else{
        res.render('404')
    }
})

module.exports = router